tailwind.config = {
    theme: {
      extend: {
        colors: {
          'red-600': '#8C4952',
          'red-800': '#57111a',
        }
      }
    }
}